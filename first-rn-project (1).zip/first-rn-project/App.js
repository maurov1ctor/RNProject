import React,{Component} from 'react';
import { StyleSheet, Text, View, TextInput, Image } from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Search Images</Text>
      <TextInput style={styles.input} placeholder="Digite aqui" keyboardType="numeric" />
      <View style={styles.labelsContainer}>
        <Text style={styles.label}>Montanhas</Text>
        <Text style={styles.label}>Praias</Text>
        <Text style={styles.label}>Comida</Text>
      </View>
      <View style={styles.imagesContainer}>
        <Image source={require('./imgs/image1.png')} style={styles.image} />
        <Image source={require('./imgs/image2.png')} style={styles.image} />
        <Image source={require('./imgs/image3.png')} style={styles.image} />
        <Image source={require('./imgs/image4.png')} style={styles.image} />
        <Image source={require('./imgs/image5.png')} style={styles.image} />
        <Image source={require('./imgs/image6.png')} style={styles.image} />
        <Image source={require('./imgs/image7.png')} style={styles.image} />
        <Image source={require('./imgs/image8.png')} style={styles.image} />
        <Image source={require('./imgs/image9.png')} style={styles.image} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
  },
  labelsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
  },
  imagesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    width: '100%',
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
});

export default App;